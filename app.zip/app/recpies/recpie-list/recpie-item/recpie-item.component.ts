import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recpie-item',
  templateUrl: './recpie-item.component.html',
  styleUrls: ['./recpie-item.component.css']
})
export class RecpieItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
