import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recpie-detail',
  templateUrl: './recpie-detail.component.html',
  styleUrls: ['./recpie-detail.component.css']
})
export class RecpieDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
