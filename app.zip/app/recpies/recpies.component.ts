import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recpies',
  templateUrl: './recpies.component.html',
  styleUrls: ['./recpies.component.css']
})
export class RecpiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
